# SL Civic Archive - MVP Execution Packet

Working title only. This packet specifies a deliberately local, vertical-slice proof of concept for a multi-tenant civic records/archive system aimed at Second Life roleplay communities.

## Contents

- `00_BUILD_SPEC.md` - product intent, architecture boundaries, data model, UX requirements, and MVP acceptance scenario.
- `01_EXECUTION_STACK.md` - ordered implementation tickets with stop/review gates and explicit acceptance criteria.
- `02_TEST_FIXTURES.md` - fixed sample tenants, documents, themes, and form data to use while implementing and reviewing the MVP.

## Core execution rule

This is not a miniature production deployment. It must prove the distinctive UX without building disposable infrastructure halfway toward production.

Use the real application shape where it is already cheap and stable: Next.js/React, Payload, Payload collections/API, Markdown documents, tenant-scoped records, and Payload's official SQLite adapter.

Be intentionally crude where production shape is not yet known: local SQLite file, local media storage, seed users, minimal authorization, simulated Second Life import/export, no deployment provider, no email, no custom domains.

Do not add abstraction layers simply because something may change later. Add a seam only where the MVP has a known substitute later.
